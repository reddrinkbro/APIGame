#pragma once
#include "gameNode.h"

class mainGame : public gameNode
{
private:
	SYSTEMTIME sysTime;
	int secondX;
	int secondY;
	int minuteX;
	int minuteY;
	int hourX;
	int hourY;
	int seconddegree;
	int minutedegree;
	int hourdegree;
public:
	HRESULT init(void);
	void release(void);
	void update(void);
	void render(HDC hdc);

	

	mainGame() {}
	~mainGame() {}
};

