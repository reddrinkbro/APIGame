#include "stdafx.h"
#include "mainGame.h"

//=========================
//	## init(void) ## �ʱ�ȭ
//=========================
HRESULT mainGame::init(void)
{
	gameNode::init();
	//�̰����� �ʱ�ȭ
	secondX = WINSIZEX / 2;
	secondY = WINSIZEY / 2-250;
	minuteX = WINSIZEX / 2;
	minuteY = WINSIZEY / 2 - 250;
	hourX = WINSIZEX / 2 ;
	hourY = WINSIZEY / 2 - 250;
	GetLocalTime(&sysTime);
	seconddegree = sysTime.wSecond * 6;
	minutedegree = sysTime.wMinute * 6;
	if (sysTime.wHour > 12)
	{
		hourdegree = (sysTime.wHour - 12) * 30;
	}
	else 
	{
		hourdegree = sysTime.wHour * 30 + 20;
	}
	
	return S_OK;
}

//=====================
//	## release(void) ##
//=====================
void mainGame::release(void)
{
	gameNode::release();
	//�����Ҵ��� �ߴٸ� ���⿡�� SAFE_DELETE() ���
}

//=============================
//	## update(void) ## ������Ʈ
//=============================
void mainGame::update(void)
{
	gameNode::update();

	seconddegree+=6;
	if (seconddegree == 360)
	{
		seconddegree = 0;
		minutedegree+=6;
	}
	if (minutedegree == 360)
	{
		minutedegree = 0;
		hourdegree+=30;
	}
	secondX = WINSIZEX / 2 + cosf((PI / 180)* (seconddegree -90)) * 250 ;
	secondY = WINSIZEY / 2 + sinf((PI / 180) * (seconddegree-90)) * 250 ;
	minuteX = WINSIZEX / 2 + cosf(PI / 180 * (minutedegree -90)) * 200;
	minuteY = WINSIZEY / 2 + sinf(PI / 180 * (minutedegree -90)) * 200;
	hourX = WINSIZEX / 2 + cosf(PI / 200 * (hourdegree -90)) * 150;
	hourY = WINSIZEY / 2 + sinf(PI / 200 * (hourdegree -90)) * 150;
	//�̰����� ����, Ű����, ���콺��� ������Ʈ�� �Ѵ�
}

//============================
//	## render(HDC hdc) ## ����
//============================

void mainGame::render(HDC hdc)
{
	char str[128];
	wsprintf(str, "%d %d %d", sysTime.wSecond,sysTime.wMinute, sysTime.wHour);
	TextOut(hdc, 0, 0, str, strlen(str));

	EllipseMakeCenter(hdc, WINSIZEX / 2, WINSIZEY / 2, 500, 500);
	LineMake(hdc, WINSIZEX / 2, WINSIZEY / 2, secondX, secondY);
	LineMake(hdc, WINSIZEX / 2, WINSIZEY / 2, minuteX, minuteY);
	LineMake(hdc, WINSIZEX / 2, WINSIZEY / 2, hourX, hourY);
}
